
let questions = [
    {
    numb: 1,
    question: "A sum of money at simple interest amounts to Rs.815 in 3 years and to Rs.854 in 4 years. The sum is:",
    answer:"Rs.698",
    options: [
      "Rs.615",
      "Rs.616",
      "Rs.698",
      "Rs.525"
    ]
  },
    {
    numb: 2,
    question: "	A sum fetched a total simple interest of Rs.4016.25 at the rate of 9 p.c.p.a. in 5 years. What is the sum?",
    answer: "8925",
    options: [
      "8925",
      "6925",
      "1000",
      "None of the above"
    ]
  },
    {
    numb: 3,
    question: "How much time will it take for an amount of Rs.450 to yield Rs.81 as interest at 4.5% per annum of simple interest?:",
    answer: "4",
    options: [
      "4",
      "2",
      "5",
      "16"
    ]
  },
    {
    numb: 4,
    question: "	A sum of Rs.12,500 amounts to Rs.15,500 in 4 years at the rate of simple interest. what is the rate of interest?",
    answer: "6%",
    options: [
      "0%",
      "6%",
      "5%",
      "4%"
    ]
  },
    {
    numb: 5,
    question: "A sum of money amounts to Rs.9800 after 5 years and Rs. 12005 after 8 years at the some rate of simple interest. The rate of interest per annum is::",
    answer: "12%",
    options: [
    "12%",
    "17%",
    "30%",
     "44%"

    ]
  },
  
];
