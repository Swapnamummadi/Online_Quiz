
let questions = [
    {
    numb: 1,
    question: "The cost price of 20 articles is the same as the selling price of x articles. If the profit is 25%,then the value of x is:",
    answer:"16",
    options: [
      "Rs.15",
      "Rs.16",
      "Rs.18",
      "Rs.25"
    ]
  },
    {
    numb: 2,
    question: "	If selling price is doubled, the profit triples. Find the profit percent?",
    answer: "100",
    options: [
      "30",
      "45",
      "100",
      "80"
    ]
  },
    {
    numb: 3,
    question: "A vendor bought toffees at 6 for a rupee. How many for a rupee must he sell to gain 20%?:",
    answer: "5",
    options: [
      "4",
      "2",
      "5",
      "16"
    ]
  },
    {
    numb: 4,
    question: "	A man buys a cycle for Rs.1400 and sells it at a loss of 15%. What is the selling price of the cycle?",
    answer: "1190",
    options: [
      "1000",
      "2000",
      "1190",
      "1500"
    ]
  },
    {
    numb: 5,
    question: "some articles were bought at 6 articles for Rs.5 and sold at 5 articles for Rs.6. Gain percent is:",
    answer: "44%",
    options: [
    "50%",
    "17%",
    "30%",
     "44%"

    ]
  },
  
];
