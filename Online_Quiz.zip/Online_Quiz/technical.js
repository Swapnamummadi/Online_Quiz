
let questions = [
    {
    numb: 1,
    question: "	How long is an IPv6 address?",
    answer:"128 bits",
    options: [
      "32 bits",
      "128 bytes",
      "128 bits",
      "64 bits"
    ]
  },
    {
    numb: 2,
    question: "What layer in the TCP/IP stack is equivalent to the Transport layer of the OSI model?",
    answer: "Host-to-Host",
    options: [
      "Host-to-Host",
      "Internet",
      "Application",
      "Network Access"
    ]
  },
    {
    numb: 3,
    question: "Which command displays RIP routing updates?",
    answer: "debug ip rip",
    options: [
      "show ip route",
      "debug ip rip",
      "show protocols",
      "debug ip route"
    ]
  },
    {
    numb: 4,
    question: "	You need to configure a router for a Frame Relay connection to a non-Cisco router. Which of the following commands will prepare the WAN interface of the router for this connection?",
    answer: "Router(config-if)#encapsulation frame-relay ietf",
    options: [
      "Router(config-if)#encapsulation frame-relay q933a",
      "Router(config-if)#encapsulation frame-relay ansi",
      "Router(config-if)#encapsulation frame-relay ietf",
      "Router(config-if)#encapsulation frame-relay cisco"
    ]
  },
    {
    numb: 5,
    question: "	Which protocol reduces administrative overhead in a switched network by allowing the configuration of a new VLAN to be distributed to all the switches in a domain?",
    answer: "VTP",
    options: [
    "STP",
    "VTP",
    "DHCP",
     "ISL"

    ]
  },
  
];
