
let questions = [
    {
    numb: 1,
    question: "	Look at this series: 2, 1, (1/2), (1/4), ... What number should come next?",
    answer:"(1/8)",
    options: [
      "(1/3)",
      "(1/8)",
      "	(2/8)",
      "	(1/16)"
    ]
  },
    {
    numb: 2,
    question: "Look at this series: 7, 10, 8, 11, 9, 12, ... What number should come next?",
    answer: "10",
    options: [
      "7",
      "10",
      "12",
      "13"
    ]
  },
    {
    numb: 3,
    question: "Look at this series: 36, 34, 30, 28, 24, ... What number should come next?",
    answer: "20",
    options: [
      "20",
      "18",
      "16",
      "None of the above"
    ]
  },
    {
    numb: 4,
    question: "	Look at this series: 22, 21, 23, 22, 24, 23, ... What number should come next?",
    answer: "25",
    options: [
      "22",
      "24",
      "25",
      "26"
    ]
  },
    {
    numb: 5,
    question: "Look at this series: 53, 53, 40, 40, 27, 27, ... What number should come next?",
    answer: "14",
    options: [
    "12",
    "14",
    "27",
     "53"

    ]
  },
  
];
