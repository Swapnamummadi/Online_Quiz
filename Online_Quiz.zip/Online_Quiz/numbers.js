
let questions = [
    {
    numb: 1,
    question: "Which one of the following is not a prime number?:",
    answer:"Rs.91",
    options: [
      "Rs.31",
      "Rs.61",
      "Rs.91",
      "Rs.71"
    ]
  },
    {
    numb: 2,
    question: "	(112 x 54) = ?",
    answer: "70000",
    options: [
      "67000",
      "70000",
      "10000",
      "80000"
    ]
  },
    {
    numb: 3,
    question: "	It is being given that (232 + 1) is completely divisible by a whole number. Which of the following numbers is completely divisible by this number?:",
    answer: "(296 + 1)",
    options: [
      "(216 + 1)",
      "(216 - 1)",
      "(7 x 223)",
      "(296 + 1)"
    ]
  },
    {
    numb: 4,
    question: "What least number must be added to 1056, so that the sum is completely divisible by 23 ?",
    answer: "2",
    options: [
      "2",
      "3",
      "18",
      "19"
    ]
  },
    {
    numb: 5,
    question: "1397 x 1397 = ?",
    answer: "1951609",
    options: [
    "1951609",
    "1981709",
    "18362619",
     "2031719"

    ]
  },
  
];
