
let questions = [
    {
    numb: 1,
    question: "	SCD, TEF, UGH, ____, WKL",
    answer:"VIJ",
    options: [
      "CMN",
      "UJI",
      "VIJ",
      "IJT"
    ]
  },
    {
    numb: 2,
    question: "B2CD, _____, BCD4, B5CD, BC6D",
    answer: "BC3D",
    options: [
      "B2C2D",
      "BC3D",
      "B2C3D",
      "BCD7"
    ]
  },
    {
    numb: 3,
    question: "FAG, GAF, HAI, IAH, ____",
    answer: "JAK",
    options: [
      "JAK",
      "HAL",
      "HAK",
      "JAI"
    ]
  },
    {
    numb: 4,
    question: "ELFA, GLHA, ILJA, _____, MLNA",
    answer: "KLLA",
    options: [
      "KLLA",
      "OLPA",
      "KLMA",
      "LLMA"
    ]
  },
    {
    numb: 5,
    question: "CMM, EOO, GQQ, _____, KUU",
    answer: "ISS",
    options: [
    "GRR",
    "GSS",
    "ISS",
     "ITT"

    ]
  },
  
];
