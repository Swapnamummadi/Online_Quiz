
let questions = [
    {
    numb: 1,
    question: "	The DBMS acts as an interface between what two components of an enterprise-class database system?",
    answer:"Database application and the database",
    options: [
      "Database application and the database",
      "Data and the database",
      "The user and the database application",
      "Database application and SQL"
    ]
  },
    {
    numb: 2,
    question: "DBMS stands for?",
    answer: "DATABASE MANAGEMENT SYSTEM",
    options: [
      "DATABASE MANAGEMENT SYSTEM",
      "DATABASE MANAGEMENT APPLICATION",
      "DATABASE MANAGEMENT SCHEME",
      "NONE OF THE ABOVE"
    ]
  },
    {
    numb: 3,
    question: "Which of the following products was an early implementation of the relational model developed by E.F. Codd of IBM?",
    answer: "DB2",
    options: [
      "IDMS",
      "DB2",
      "dBase-II",
      "	R:base"
    ]
  },
    {
    numb: 4,
    question: "	The following are components of a database except ________ .",
    answer: "reports",
    options: [
      "user data",
      "metadata",
      "reports",
      "ALl Of the Above"
    ]
  },
    {
    numb: 5,
    question: "	An application where only one user accesses the database at a given time is an example of a(n) ________ .",
    answer: "single-user database application",
    options: [
    "single-user database application",
    "multiuser database application",
    "e-commerce database application",
    "data mining database application"

    ]
  },
  
];
