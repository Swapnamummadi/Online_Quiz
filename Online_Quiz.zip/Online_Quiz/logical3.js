
let questions = [
    {
    numb: 1,
    question: "Which word does NOT belong with the others?",
    answer:"mayonnaise",
    options: [
      "parsley",
      "basil",
      "dill",
      "mayonnaise"
    ]
  },
    {
    numb: 2,
    question: "Which word does NOT belong with the others?",
    answer: "ounce",
    options: [
      "inch",
      "ounce",
      "centimeter",
      "yard"
    ]
  },
    {
    numb: 3,
    question: "Which word does NOT belong with the others?",
    answer: "car",
    options: [
      "tyre",
      "steering wheel",
      "engine",
      "car"
    ]
  },
    {
    numb: 4,
    question: "Which word does NOT belong with the others?",
    answer: "bud",
    options: [
      "tulip",
      "bud",
      "rose",
      "daisy"
    ]
  },
    {
    numb: 5,
    question: "	Which word does NOT belong with the others?",
    answer: "rye",
    options: [
    "rye",
    "sourdough",
    "pumpernickel",
     "loaf"

    ]
  },
  
];
